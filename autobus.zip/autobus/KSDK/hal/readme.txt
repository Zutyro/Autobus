Files from KSDK/platform/hal/include and .../hal/src/i2c (and possible other HAL source directories in future)

fsl_misc_utilities.h is from platform/utilities/inc
fsl_device_registers is from KSDK/platform/registers - it includes the apropriate <device.h> file.

Note: fsl_device_registers.h file removed; it is not used, commented out in fsl_xxx_hal.h files for our use.