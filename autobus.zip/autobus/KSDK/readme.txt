Files from Freescale Kinetis SDK (KSDK) which are used by some driver(s).

Current version of KSDK: 1.2.0