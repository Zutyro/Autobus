Files from Kinetis SDK: platform/devices/MKL25Z4/include

NOTE: in projects use only:
 fsl_bitaccess.h
 MKL25Z4_extension.h
 MKL25Z4_features.h

The MKL25Z4.h file (<device>.h file) is already included by new project wizard in the project.